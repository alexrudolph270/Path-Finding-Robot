var classfinal__main__tcp_1_1_map =
[
    [ "__init__", "classfinal__main__tcp_1_1_map.html#a9a08b04220eeb2353f53ea82b648153e", null ],
    [ "onClose", "classfinal__main__tcp_1_1_map.html#a651bf1dd8fd68757879d6dcb3cd67150", null ],
    [ "original_frame", "classfinal__main__tcp_1_1_map.html#a20619f4ef2dbea18675d83c7875315a7", null ]
];