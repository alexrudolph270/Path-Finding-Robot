var dir_58b93d016ce50d4992277add032f5acb =
[
    [ "matrixdraw.py", "matrixdraw_8py.html", "matrixdraw_8py" ],
    [ "path_mode.py", "path__mode_8py.html", "path__mode_8py" ],
    [ "path_mode_tcp.py", "path__mode__tcp_8py.html", "path__mode__tcp_8py" ]
];