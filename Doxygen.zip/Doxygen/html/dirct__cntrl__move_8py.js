var dirct__cntrl__move_8py =
[
    [ "key_input", "dirct__cntrl__move_8py.html#a7d1ba5babbbf9e2c67531c6e190d156a", null ],
    [ "command", "dirct__cntrl__move_8py.html#a9e0992eae3950adccaf4847fbff4231d", null ],
    [ "servo_range", "dirct__cntrl__move_8py.html#a51eedaf091c0bc5c896cd56537399570", null ]
];