var dir_f652bb1280b20cc2fde8a67f7d890eb6 =
[
    [ "final_main.py", "final__main_8py.html", "final__main_8py" ],
    [ "final_main_tcp.py", "final__main__tcp_8py.html", "final__main__tcp_8py" ]
];