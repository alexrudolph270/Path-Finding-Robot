var searchData=
[
  ['host',['host',['../namespacerob__client.html#a4b730861b8c2165bfeabd34968e25e37',1,'rob_client.host()'],['../namespacerob__server.html#a4b730861b8c2165bfeabd34968e25e37',1,'rob_server.host()']]]
];
