var searchData=
[
  ['s',['s',['../namespacerob__client.html#a3691308f2a4c2f6983f2880d32e29c84',1,'rob_client.s()'],['../namespacerob__server.html#a3691308f2a4c2f6983f2880d32e29c84',1,'rob_server.s()']]],
  ['send_5fcommand',['send_command',['../namespacerob__client.html#ad332048e8b40733f281f1d894c13fab2',1,'rob_client']]],
  ['server_5fmapmode',['server_mapmode',['../namespacerob__server.html#a965fbd8c86d247821908a446136cb8fb',1,'rob_server']]],
  ['servo_5frange',['servo_range',['../namespacedirct__cntrl__move.html#a51eedaf091c0bc5c896cd56537399570',1,'dirct_cntrl_move']]],
  ['set_5fdelay',['set_delay',['../classfinal__main_1_1_direct.html#ad6e5b088d2af54555432be206007948e',1,'final_main.Direct.set_delay()'],['../classfinal__main__tcp_1_1_direct.html#ad6e5b088d2af54555432be206007948e',1,'final_main_tcp.Direct.set_delay()']]],
  ['set_5finput',['set_input',['../classfinal__main_1_1_direct.html#a29c3e6ae140b2f570a78844156f78475',1,'final_main.Direct.set_input()'],['../classfinal__main__tcp_1_1_direct.html#a29c3e6ae140b2f570a78844156f78475',1,'final_main_tcp.Direct.set_input()']]],
  ['setinput',['setInput',['../namespacedc__test.html#a0c951ccbcd1b053ee4cfeb437a075ab6',1,'dc_test']]],
  ['show',['show',['../classfinal__main_1_1_menu.html#ab4f4398c3f210fe4ea6e720401357691',1,'final_main.Menu.show()'],['../classfinal__main__tcp_1_1_menu.html#ab4f4398c3f210fe4ea6e720401357691',1,'final_main_tcp.Menu.show()']]],
  ['sleep_5ft',['sleep_t',['../namespacerotate__test.html#a95f29933e3f194aba8ddef745f4797f8',1,'rotate_test']]],
  ['speed',['speed',['../namespacerotate__test.html#a218b4f7c6cc2681a99c23a3b089d68b1',1,'rotate_test']]],
  ['start',['start',['../namespacematrixdraw.html#a550769bbd4e7537ff90a656f5b0c23b2',1,'matrixdraw']]],
  ['startup_5ftest',['startup_test',['../namespacestartup__test.html',1,'']]],
  ['startup_5ftest_2epy',['startup_test.py',['../startup__test_8py.html',1,'']]]
];
