var searchData=
[
  ['s',['s',['../namespacerob__client.html#a3691308f2a4c2f6983f2880d32e29c84',1,'rob_client.s()'],['../namespacerob__server.html#a3691308f2a4c2f6983f2880d32e29c84',1,'rob_server.s()']]],
  ['servo_5frange',['servo_range',['../namespacedirct__cntrl__move.html#a51eedaf091c0bc5c896cd56537399570',1,'dirct_cntrl_move']]],
  ['sleep_5ft',['sleep_t',['../namespacerotate__test.html#a95f29933e3f194aba8ddef745f4797f8',1,'rotate_test']]],
  ['speed',['speed',['../namespacerotate__test.html#a218b4f7c6cc2681a99c23a3b089d68b1',1,'rotate_test']]],
  ['start',['start',['../namespacematrixdraw.html#a550769bbd4e7537ff90a656f5b0c23b2',1,'matrixdraw']]]
];
