var searchData=
[
  ['hide',['hide',['../classfinal__main_1_1_menu.html#ac3c535fd36dc5473ff98017920898352',1,'final_main.Menu.hide()'],['../classfinal__main__tcp_1_1_menu.html#ac3c535fd36dc5473ff98017920898352',1,'final_main_tcp.Menu.hide()']]],
  ['host',['host',['../namespacerob__client.html#a4b730861b8c2165bfeabd34968e25e37',1,'rob_client.host()'],['../namespacerob__server.html#a4b730861b8c2165bfeabd34968e25e37',1,'rob_server.host()']]]
];
