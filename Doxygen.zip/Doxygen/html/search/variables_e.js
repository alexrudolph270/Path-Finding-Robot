var searchData=
[
  ['received',['received',['../namespacerob__server.html#a660717d26371e4a9312de112b86f655c',1,'rob_server']]],
  ['root',['root',['../classfinal__main_1_1_menu.html#ab4b8daf4b8ea9d39568719e1e320076f',1,'final_main.Menu.root()'],['../classfinal__main__tcp_1_1_menu.html#ab4b8daf4b8ea9d39568719e1e320076f',1,'final_main_tcp.Menu.root()'],['../namespacefinal__main.html#ab4b8daf4b8ea9d39568719e1e320076f',1,'final_main.root()'],['../namespacefinal__main__tcp.html#ab4b8daf4b8ea9d39568719e1e320076f',1,'final_main_tcp.root()'],['../namespacemxout.html#ab4b8daf4b8ea9d39568719e1e320076f',1,'mxout.root()']]],
  ['rotate',['rotate',['../namespacerotate__test.html#a0b95db0f87fcbe71c3bbda1fa359606f',1,'rotate_test']]],
  ['row',['row',['../namespacematrixdraw.html#ad42e2d1ad172100a2cd1338656cf0425',1,'matrixdraw']]]
];
