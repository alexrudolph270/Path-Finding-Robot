var searchData=
[
  ['direct',['Direct',['../classfinal__main_1_1_direct.html',1,'final_main']]],
  ['direct',['Direct',['../classfinal__main__tcp_1_1_direct.html',1,'final_main_tcp']]]
];
