var searchData=
[
  ['hide',['hide',['../classfinal__main_1_1_menu.html#ac3c535fd36dc5473ff98017920898352',1,'final_main.Menu.hide()'],['../classfinal__main__tcp_1_1_menu.html#ac3c535fd36dc5473ff98017920898352',1,'final_main_tcp.Menu.hide()']]]
];
