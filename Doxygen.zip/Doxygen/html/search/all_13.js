var searchData=
[
  ['x',['x',['../namespacematrixdraw.html#a9336ebf25087d91c818ee6e9ec29f8c1',1,'matrixdraw']]],
  ['xlen',['xlen',['../namespacemxout.html#a78591da589b76baac20e376b3990bef1',1,'mxout']]]
];
