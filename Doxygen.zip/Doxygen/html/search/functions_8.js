var searchData=
[
  ['receive_5fcommand',['receive_command',['../namespacerob__server.html#ad4cca5b58f398f7c3d2010d388ba1c6f',1,'rob_server']]],
  ['request_5fmap_5fmode',['request_map_mode',['../namespacerob__client.html#af28d922303df0fa13b1c83c0ba010273',1,'rob_client']]],
  ['reset_5fcolors',['reset_colors',['../classfinal__main_1_1_direct.html#a5688cb94e1c7a4f9fb09a5f8429ce5d2',1,'final_main.Direct.reset_colors()'],['../classfinal__main__tcp_1_1_direct.html#a5688cb94e1c7a4f9fb09a5f8429ce5d2',1,'final_main_tcp.Direct.reset_colors()']]]
];
