var searchData=
[
  ['readme_2emd',['README.md',['../_r_e_a_d_m_e_8md.html',1,'']]],
  ['receive_5fcommand',['receive_command',['../namespacerob__server.html#ad4cca5b58f398f7c3d2010d388ba1c6f',1,'rob_server']]],
  ['received',['received',['../namespacerob__server.html#a660717d26371e4a9312de112b86f655c',1,'rob_server']]],
  ['request_5fmap_5fmode',['request_map_mode',['../namespacerob__client.html#af28d922303df0fa13b1c83c0ba010273',1,'rob_client']]],
  ['reset_5fcolors',['reset_colors',['../classfinal__main_1_1_direct.html#a5688cb94e1c7a4f9fb09a5f8429ce5d2',1,'final_main.Direct.reset_colors()'],['../classfinal__main__tcp_1_1_direct.html#a5688cb94e1c7a4f9fb09a5f8429ce5d2',1,'final_main_tcp.Direct.reset_colors()']]],
  ['rob_5fclient',['rob_client',['../namespacerob__client.html',1,'']]],
  ['rob_5fclient_2epy',['rob_client.py',['../rob__client_8py.html',1,'']]],
  ['rob_5fserver',['rob_server',['../namespacerob__server.html',1,'']]],
  ['rob_5fserver_2epy',['rob_server.py',['../rob__server_8py.html',1,'']]],
  ['root',['root',['../classfinal__main_1_1_menu.html#ab4b8daf4b8ea9d39568719e1e320076f',1,'final_main.Menu.root()'],['../classfinal__main__tcp_1_1_menu.html#ab4b8daf4b8ea9d39568719e1e320076f',1,'final_main_tcp.Menu.root()'],['../namespacefinal__main.html#ab4b8daf4b8ea9d39568719e1e320076f',1,'final_main.root()'],['../namespacefinal__main__tcp.html#ab4b8daf4b8ea9d39568719e1e320076f',1,'final_main_tcp.root()'],['../namespacemxout.html#ab4b8daf4b8ea9d39568719e1e320076f',1,'mxout.root()']]],
  ['rotate',['rotate',['../namespacerotate__test.html#a0b95db0f87fcbe71c3bbda1fa359606f',1,'rotate_test']]],
  ['rotate_5ftest',['rotate_test',['../namespacerotate__test.html',1,'']]],
  ['rotate_5ftest_2epy',['rotate_test.py',['../rotate__test_8py.html',1,'']]],
  ['row',['row',['../namespacematrixdraw.html#ad42e2d1ad172100a2cd1338656cf0425',1,'matrixdraw']]]
];
