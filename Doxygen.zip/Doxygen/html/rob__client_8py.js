var rob__client_8py =
[
    [ "request_map_mode", "rob__client_8py.html#af28d922303df0fa13b1c83c0ba010273", null ],
    [ "send_command", "rob__client_8py.html#ad332048e8b40733f281f1d894c13fab2", null ],
    [ "data", "rob__client_8py.html#a511ae0b1c13f95e5f08f1a0dd3da3d93", null ],
    [ "host", "rob__client_8py.html#a4b730861b8c2165bfeabd34968e25e37", null ],
    [ "MAX_COMMAND_SIZE", "rob__client_8py.html#ab6c67b302bcb2eef92817148f5924897", null ],
    [ "port", "rob__client_8py.html#a63c89c04d1feae07ca35558055155ffb", null ],
    [ "s", "rob__client_8py.html#a3691308f2a4c2f6983f2880d32e29c84", null ]
];