var rotate__test_8py =
[
    [ "rotate", "rotate__test_8py.html#a0b95db0f87fcbe71c3bbda1fa359606f", null ],
    [ "sleep_t", "rotate__test_8py.html#a95f29933e3f194aba8ddef745f4797f8", null ],
    [ "speed", "rotate__test_8py.html#a218b4f7c6cc2681a99c23a3b089d68b1", null ]
];