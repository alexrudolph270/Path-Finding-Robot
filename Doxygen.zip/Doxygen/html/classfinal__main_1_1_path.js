var classfinal__main_1_1_path =
[
    [ "__init__", "classfinal__main_1_1_path.html#a9a08b04220eeb2353f53ea82b648153e", null ],
    [ "clickpath", "classfinal__main_1_1_path.html#a8c049f30497413ec98e55d16230ee6d3", null ],
    [ "clickstart", "classfinal__main_1_1_path.html#a3df0eafca14ca129a8b13bdf8063c45e", null ],
    [ "dimensions", "classfinal__main_1_1_path.html#a7acef0b75efe7a8eb4df3af0b7449539", null ],
    [ "onClose", "classfinal__main_1_1_path.html#a651bf1dd8fd68757879d6dcb3cd67150", null ],
    [ "orderindex", "classfinal__main_1_1_path.html#a644ab56447350c1ebd7c36438b2f04db", null ],
    [ "original_frame", "classfinal__main_1_1_path.html#a20619f4ef2dbea18675d83c7875315a7", null ],
    [ "path", "classfinal__main_1_1_path.html#aa28dc103258589d9cb421197fe2de90b", null ],
    [ "pathButtons", "classfinal__main_1_1_path.html#aa15c4f66ed5b0dfcd8ab1d3815bcfa0f", null ]
];