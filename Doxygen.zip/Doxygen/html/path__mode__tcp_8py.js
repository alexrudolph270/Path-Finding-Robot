var path__mode__tcp_8py =
[
    [ "dimensions", "path__mode__tcp_8py.html#ae1e3248879bd25f8507e59fef9888375", null ],
    [ "orient", "path__mode__tcp_8py.html#a18063d9da80e7c9cbbb8d97c1ea6937d", null ],
    [ "path_mode", "path__mode__tcp_8py.html#a6f3fad462be5a2dfbd9099bf1d9c1c54", null ]
];