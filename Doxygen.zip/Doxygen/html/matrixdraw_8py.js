var matrixdraw_8py =
[
    [ "clickpath", "matrixdraw_8py.html#a9ecb0a4e27573b4b8de8490ca392e3a5", null ],
    [ "clickstart", "matrixdraw_8py.html#a792627add5d38c7ef0d21de7e30545c5", null ],
    [ "dimensions", "matrixdraw_8py.html#a7f5e88405e21c499229481bed6d20760", null ],
    [ "butt", "matrixdraw_8py.html#a57aa36de034e914641557bbb34ebe3dd", null ],
    [ "col", "matrixdraw_8py.html#a0d819d653099fa8cc7910fcdcfbe3e72", null ],
    [ "column", "matrixdraw_8py.html#ae78e6e11a40e6dba1bae097358f97d15", null ],
    [ "orderindex", "matrixdraw_8py.html#a0e64ef66e0ac39ecba2ecaa5ed6d6125", null ],
    [ "path", "matrixdraw_8py.html#aaa464bac0a9aa6dad47740f3f330c7ed", null ],
    [ "pathButtons", "matrixdraw_8py.html#a0930fdb41fe22d33be9e0b8b29f6651f", null ],
    [ "row", "matrixdraw_8py.html#ad42e2d1ad172100a2cd1338656cf0425", null ],
    [ "start", "matrixdraw_8py.html#a550769bbd4e7537ff90a656f5b0c23b2", null ],
    [ "window", "matrixdraw_8py.html#a04a8a2bbfa9c15500892b8e5033d625b", null ],
    [ "x", "matrixdraw_8py.html#a9336ebf25087d91c818ee6e9ec29f8c1", null ]
];